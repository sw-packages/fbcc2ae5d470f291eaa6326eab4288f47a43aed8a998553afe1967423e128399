<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ko_KR">
<context>
    <name>QQuickPlatformDialog</name>
    <message>
        <source>Dialog is an abstract base class</source>
        <translation>Dialog는 추상 기반 클래스임</translation>
    </message>
    <message>
        <source>Cannot create an instance of StandardButton</source>
        <translation>StandardButton의 인스턴스를 만들 수 없음</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2MaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>Material은 첨부된 속성임</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2UniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>Universal은 첨부된 속성임</translation>
    </message>
</context>
</TS>
